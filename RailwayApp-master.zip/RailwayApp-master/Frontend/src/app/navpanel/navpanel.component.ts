import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navpanel',
  templateUrl: './navpanel.component.html',
  styleUrls: ['./navpanel.component.css']
})
export class NavpanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
