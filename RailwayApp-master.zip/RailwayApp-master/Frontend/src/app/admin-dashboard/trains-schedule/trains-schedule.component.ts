import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trains-schedule',
  templateUrl: './trains-schedule.component.html',
  styleUrls: ['./trains-schedule.component.css']
})
export class TrainsScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
