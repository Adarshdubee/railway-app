import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-notifications',
  templateUrl: './admin-notifications.component.html',
  styleUrls: ['./admin-notifications.component.css']
})
export class AdminNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
