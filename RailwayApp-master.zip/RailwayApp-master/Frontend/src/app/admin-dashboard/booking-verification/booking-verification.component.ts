import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-verification',
  templateUrl: './booking-verification.component.html',
  styleUrls: ['./booking-verification.component.css']
})
export class BookingVerificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
