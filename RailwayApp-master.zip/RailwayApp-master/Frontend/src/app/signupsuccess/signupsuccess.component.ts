import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signupsuccess',
  templateUrl: './signupsuccess.component.html',
  styleUrls: ['./signupsuccess.component.css']
})
export class SignupsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
