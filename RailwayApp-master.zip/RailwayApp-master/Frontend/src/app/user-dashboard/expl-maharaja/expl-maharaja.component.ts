import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expl-maharaja',
  templateUrl: './expl-maharaja.component.html',
  styleUrls: ['./expl-maharaja.component.css']
})
export class ExplMaharajaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0);
  }

}
