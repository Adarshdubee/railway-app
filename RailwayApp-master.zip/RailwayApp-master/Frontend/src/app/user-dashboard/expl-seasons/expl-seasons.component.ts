import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expl-seasons',
  templateUrl: './expl-seasons.component.html',
  styleUrls: ['./expl-seasons.component.css']
})
export class ExplSeasonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0);
  }

}
