import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expl-india',
  templateUrl: './expl-india.component.html',
  styleUrls: ['./expl-india.component.css']
})
export class ExplIndiaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0);
  }

}
